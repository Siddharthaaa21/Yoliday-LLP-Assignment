package com.example.yoliday_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
